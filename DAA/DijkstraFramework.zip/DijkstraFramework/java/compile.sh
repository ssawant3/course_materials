javac -cp .:junit-4.12.jar Dijkstra.java DijkstraTest.java
